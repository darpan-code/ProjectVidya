<?php 

    if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }

    include('admindata/course_db.php');

    // checking for entry 
    if(isset($_REQUEST['submit_student'])){

       if(
       ($_REQUEST['student_name'] == "") ||
       ($_REQUEST['student_email'] == "") || 
       ($_REQUEST['student_password'] == "") || 
       ($_REQUEST['student_status'] == "") || 
       ($_REQUEST['student_occupation'] == "")
        ){
            $msg = '<div class="fill_error">Fill All Fields</div>';
            echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
        }
        else {
            $student_name = $_REQUEST['student_name'];
            $student_email = $_REQUEST['student_email'];
            $student_password = $_REQUEST['student_password'];
            $student_status = $_REQUEST['student_status'];
            $student_occupation = $_REQUEST['student_occupation'];
            $student_img = $_FILES['student_img']['name'];
            $student_img_temp = $_FILES['student_img']['tmp_name'];
            $img_folder = '../img/user_image/'.$student_img;
            move_uploaded_file($student_img_temp, $img_folder);
            $encpass = password_hash($student_password, PASSWORD_BCRYPT);


             $sql = "INSERT INTO user (name, email, password, status, occupation, image) VALUES ('$student_name', '$student_email', '$encpass', '$student_status', '$student_occupation',  '$img_folder')";


             if($conn->query($sql) == TRUE){
                $msg = '<div class="add_success">Student Added Succesfully</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Student_Added_Succesfully" />';
            }
            else{
                $msg = '<div class="fill_error">Unable to Add Student</div>';
                echo '<meta http-equiv="refresh" content="0;URL=?Unable_to_Add_Student" />';
            }
        }
    }
?>


<!DOCTYPE html>
<html>
<head>
	<title>Add New Student</title>
	<link rel="stylesheet" type="text/css" href="admin_css/add_student.css">
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <div class="add_student_main">
        <div class="add_student_head">Add New Student</div>
        <div class="add_student_upper">
            <form class="add_student_login" action="" method="POST" enctype="multipart/form-data">

            <input class="add_student_textbox form-control" type="text" id="student_name" name="student_name" placeholder="Type your student name here..." value="" required>

            <input class="add_student_textbox form-control" type="email" id="student_email" name="student_email" placeholder="Type your student email here..." value="" required>

            <input class="add_student_textbox form-control" type="password" id="student_password" name="student_password" placeholder="Type your student password here..." value="" required>

            <input class="add_student_textbox form-control" type="text" id="student_occupation" name="student_occupation" placeholder="Type your student occupation here..." value="" required>

            <input type="file" class="add_student_textbox form-control" id="student_img" name="student_img" accept="image/png, image/jpeg" required>

            <select class="add_student_textbox form-control" name="student_status" id="student_status" placeholder="Select Student Status here..." required>
                    <option value="">Select status</option>
                    <option value="verified">Verified</option>
                    <option value="notverified">not verified</option>
                </select>

                            
                <input class="add_student_submit" type="submit" value="Add Student" name="submit_student">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>


</body>
</html>


