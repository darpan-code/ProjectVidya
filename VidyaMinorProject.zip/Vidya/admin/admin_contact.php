
<?php 
    if(!isset($_SESSION)){
      session_start();
    }
    
    if(isset($_SESSION['is_admin_login'])){
      $adminEmail = $_SESSION['admin'];
    }else{
      header('location:../index.php');
    }

    
    include('admindata/course_db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Contact</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <!-- navbar -->
    
    <div class="admin_nav">
    <a href="admin_dashboard.php"> <div class="admin_navlink"> Dashboard </div></a>
    <a href="admin_course.php"> <div class="admin_navlink"> Course </div></a>
    <a href="admin_lessons.php"><div class="admin_navlink"> Lessons </div></a>
    <a href="admin_student.php"><div class="admin_navlink"> Students </div></a>
    <a href="admin_sellreport.php"><div class="admin_navlink"> Sell Report </div></a>
    <a href="admin_payment.php"><div class="admin_navlink"> Payment Status </div></a>
    <a href="admin_feedback.php"><div class="admin_navlink"> Feedback </div></a>
    <a href="help_center.php"><div class="admin_navlink"> Help Center </div></a>
    <a href="admin_contact.php"><div class="admin_navlink active"> <i class="fas fa-envelope"></i></div></a>
    <a href="admin_profile.php"><div class="admin_navlink"><i class="fas fa-user-circle"></i></div></a>
    <a href="admindata/logout.php"><div class="admin_navlink"> <i class="fas fa-sign-out-alt"></i> </div></a>
    </div>

<div class="mtop">
    <div class="dash_course_order">
        List Of Message
    </div>
    </div>


    <?php 

    $sql = "SELECT * FROM contact;";
    $result = $conn->query($sql);
    if($result->num_rows > 0)
    {
    ?>

<!-- table -->

    <table class="table text-justify">
        <thead class="dash_table align-middle">
          <tr>
            <th scope="col">Message ID</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Subject</th>
            <th scope="col">Message</th>
            <th scope="col">Remove</th>
          </tr>
        </thead>
        <tbody>

        <?php  while($row = $result->fetch_assoc()){
           
          echo '<tr>';
          echo '<th scope="row">'.$row['id'].'</th>';
          echo '<td>'.$row['name'].'</td>'; 
          echo '<td class="email_stu">'.$row['email'].'</td>'; 
          echo '<td>'.$row['subject'].'</td>'; 
          echo '<td class="desc_justify">'.$row['message'].'</td>';

          echo '  <td>
                <button  name ="delete" data-id='.$row["id"].' value="delete" class="course_btn delete-btn">
                <i class="fas fa-trash-alt"></i></button>
                </td>';
          echo '</tr>';

          } ?>
        </tbody>
      </table>

      <?php  
    }
      else {
        echo "<div style='font-size:2rem; font-weight: bold; color: red'> <center>No Message for you</center></div>";
      }
      ?>



    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


    <script>
      $(document).on("click", ".delete-btn", function(){

        if(confirm("Are you sure you want to delete this item?")){

        var message_id =$(this).data("id");
        // alert(course_id);

        // var element = this;

        $.ajax({
          url : "delete_message.php",
          type : "POST",
          data : {id : message_id},
          success : function(data){
              if(data == 1){
                // $(element).closest("tr").fadeOut();
              }else{

                //  alert("unable");
                
              }
          }
        });
        location.reload();  
        
        }

      })
      
    </script>
</body>

</html>