<?php
header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");


if(!isset($_SESSION)){
        session_start();
    }
  
    if(isset($_SESSION['is_admin_login'])){
        $adminEmail = $_SESSION['admin'];
        }else{
        header('location:../index.php');
        }


        include('admindata/course_db.php');


	// following files need to be included
	require_once("../paytmkit/lib/config_paytm.php");
	require_once("../paytmkit/lib/encdec_paytm.php");

	$ORDER_ID = "";
	$requestParamList = array();
	$responseParamList = array();

	if (isset($_POST["ORDER_ID"]) && $_POST["ORDER_ID"] != "") {

		// In Test Page, we are taking parameters from POST request. In actual implementation these can be collected from session or DB. 
		$ORDER_ID = $_POST["ORDER_ID"];

		// Create an array having all required parameters for status query.
		$requestParamList = array("MID" => PAYTM_MERCHANT_MID , "ORDERID" => $ORDER_ID);  
		
		$StatusCheckSum = getChecksumFromArray($requestParamList,PAYTM_MERCHANT_KEY);
		
		$requestParamList['CHECKSUMHASH'] = $StatusCheckSum;

		// Call the PG's getTxnStatusNew() function for verifying the transaction status.
		$responseParamList = getTxnStatusNew($requestParamList);
	}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Patment</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">

    <!-- <link rel="stylesheet" href="../css/bootstrap.min.css"> -->
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <!-- navbar -->
    <div class="admin_nav">
    <a href="admin_dashboard.php"> <div class="admin_navlink"> Dashboard </div></a>
    <a href="admin_course.php"> <div class="admin_navlink"> Course </div></a>
    <a href="admin_lessons.php"><div class="admin_navlink"> Lessons </div></a>
    <a href="admin_student.php"><div class="admin_navlink"> Students </div></a>
    <a href="admin_sellreport.php"><div class="admin_navlink"> Sell Report </div></a>
    <a href="admin_payment.php"><div class="admin_navlink active"> Payment Status </div></a>
    <a href="admin_feedback.php"><div class="admin_navlink"> Feedback </div></a>
    <a href="help_center.php"><div class="admin_navlink"> Help Center </div></a>
    <a href="admin_contact.php"><div class="admin_navlink"> <i class="fas fa-envelope"></i></div></a>
    <a href="admin_profile.php"><div class="admin_navlink"><i class="fas fa-user-circle"></i></div></a>
    <a href="admindata/logout.php"><div class="admin_navlink"> <i class="fas fa-sign-out-alt"></i> </div></a>
    </div>



    <div class="course_id_main mtop">
      <div class="course_id_2">
        <div class="course_id"> <p> Order ID </p></div>
          <form class="course_search"  method="post" action="">
            <input class="course_id_txt form-control" id="ORDER_ID" name="ORDER_ID" autocomplete="off" type="text" placeholder="Type your Order ID here..." value="<?php echo $ORDER_ID ?>">

            <input class="course_id_btn" type="submit" value="Search" onclick="">
          
      </div>
    </div>

    <?php
		if (isset($responseParamList) && count($responseParamList)>0 )
		{ 
		?>

    <div class="container" id="container" style="margin-top:5rem">
      <div class="row justify-content-center">
        <div class="col-auto">
          <h2 class="text-center">Payment Receipt</h2>

          <table class="table table-bordered">
			<tbody>
				<?php
					foreach($responseParamList as $paramName => $paramValue) {
				?>
				<tr >
					<td><label><?php echo $paramName?></label></td>
					<td><?php echo $paramValue?></td>
				</tr>
				<?php
					}
				?>
			</tbody>
		</table>

        </div>
      </div>
    </div>
    <div class="print_sell">
      <button type= "button" class="sell_btn" onclick="printDiv()">Payment Receipt</button>
      </div>

      <br>
      <br>
      <br>
    
		<?php
		}
		?>



    <script>
       function printDiv() {
            var divContents = document.getElementById("container").innerHTML;
            var a = window.open('', '', 'height=500, width=500');
            a.document.write('<html>');
            a.document.write('<body >');
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <script src="../js/jquery.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>