<?php

if(!isset($_SESSION)){
	// session_start();
  }

$con = mysqli_connect('localhost', 'root' );
if($con){
	// echo "conenction successful";
}else{
	echo "no connection";
}


?>


<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="admin_css/admin_login.css">
	<link href="../css/media.css" rel="stylesheet">
</head>
<body>

    <div class="adminlogin_main">
        <div class="adminlogin_head">Admin Login</div>
        <div class="adminlogin_upper">
            <form class="admin_login" action="admin/admindata/logincheck.php" method="POST">
                
                <input class="adminlogin_textbox form-control" type="email" id="adminsign_email" name="email" placeholder="Type your email here..." value="">

                <input class="adminlogin_textbox form-control" type="password" id="adminsign_password" name="pass" placeholder="Type your password here..." value="">
                
                <input class="admin_submit" type="submit" value="Log in" name="submit">
            </form>
        </div>
    </div>




<!-- 

<header>
	<div class="container center-div shadow ">
		<div class="heading text-center mb-5 text-uppercase text-white"> ADMIN LOGIN PAGE </div>
		<div class="container row d-flex flex-row justify-content-center mb-5">
			<div class="admin-form shadow p-2 ">
					<form action="logincheck.php" method="POST">
						<div class="form-group">
							<label>Email ID</label>
							<input type="text" name="user" value="" class="form-control" autocomplete="off">
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="text" name="pass" value="" class="form-control" autocomplete="off">
						</div>
						<input type="submit" class="btn btn-success" name="submit" >
				</form>
			</div>
		</div>
	</div>
</header> -->

</body>
</html