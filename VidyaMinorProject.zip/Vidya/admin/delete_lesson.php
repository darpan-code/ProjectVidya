    <!-- lesson delete  -->

    <?php

        if(!isset($_SESSION)){
            session_start();
        }

         $lesson_id = $_POST['id'];

  include('admindata/course_db.php');

          $sql = "DELETE FROM lesson WHERE lesson_id = {$lesson_id}";
        
          if($conn->query($sql) == TRUE){
            // echo '<meta http-equiv="refresh" content="0;URL=?deleted" />';
          } else {
            // echo "Unable to Delete Data";
            //             echo '<meta http-equiv="refresh" content="0;URL=?unable_to_delete" />';
          }
          
        ?>