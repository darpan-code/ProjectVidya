<?php 
    if(!isset($_SESSION)){
            session_start();
        }
    
        if(isset($_SESSION['is_admin_login'])){
            $adminEmail = $_SESSION['admin'];
            }else{
            header('location:../index.php');
            }

    include('admindata/course_db.php');


    //Update Admin details 
    
    if(isset($_REQUEST['adminupdate'])){

        // checking for empty fields 

    if(($_REQUEST['admin_id'] == "") ||
     ($_REQUEST['admin_name'] == "") ||
     ($_REQUEST['admin_email'] == "") || 
     ($_REQUEST['admin_password'] == "") || 
     ($_REQUEST['admin_occupation'] == "") || 
     ($_REQUEST['admin_social'] == "")
     ){
         //if filds missing
         $msg = '<div class="fill_error">Fill All Fields</div>';
         echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
     }
     else {
          $admin_id = $_REQUEST['admin_id'];
          $admin_name = $_REQUEST['admin_name'];
          $admin_email = $_REQUEST['admin_email'];
          $admin_password = $_REQUEST['admin_password'];
          $admin_occupation = $_REQUEST['admin_occupation'];
          $admin_social = $_REQUEST['admin_social'];

          $img_folder = $_REQUEST['image'];
        
          if($_FILES['admin_img']['error'] == 0){
            $admin_img = $_FILES['admin_img']['name'];
            $admin_img_temp = $_FILES['admin_img']['tmp_name'];
            $img_folder = '../img/admin_image/'.$admin_img;
            move_uploaded_file($admin_img_temp, $img_folder);
          }
        


          $sql = "UPDATE admin SET name = '$admin_name', email = '$admin_email', password= '$admin_password', image= '$img_folder', occupation='$admin_occupation', social='$admin_social'  WHERE id = '$admin_id'";

          if($conn->query($sql) == TRUE){

            // //submit success
            //  $msg = '<div class="add_success">Admin Update Succesfully</div>';
            //  echo '<meta http-equiv="refresh" content="0;URL=?updated" />';
            header("Location: admin_profile.php");

         }
         else{
            //  $msg = '<div class="fill_error">Unable to Update Admin</div>';
            //  echo '<meta http-equiv="refresh" content="0;URL=?fail_to_update" />';
         }
     }
 }
?>





<!DOCTYPE html>
<html>
<head>
	<title>Edit Admin</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" type="text/css" href="admin_css/edit_admin.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="admin_css/edit_admin.css">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>
<div class="edit_body">

    <div class="edit_admin_main">
        <div class="edit_admin_head">Edit Admin</div>

        <?php
            if(isset($_REQUEST['view'])){
                $sql = "SELECT * FROM admin WHERE id = {$_REQUEST['a_id']}";

            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
        }
        ?>

        <div class="edit_admin_upper">
            <form class="edit_admin_login" action="" method="POST" enctype="multipart/form-data">
                
                <input class="edit_admin_textbox form-control" type="text" id="admin_id" name="admin_id" placeholder="Type your admin id here..." value="<?php if(isset($row['id'])) {echo $row['id'] ;}?>" readonly>

                <input class="edit_admin_textbox form-control" type="text" id="admin_name" name="admin_name" placeholder="Type your admin name here..." value="<?php if(isset($row['name'])) {echo $row['name'] ;}?>" required>
                
                <input class="edit_admin_textbox form-control" type="email" id="admin_email" name="admin_email" placeholder="Type your admin email here..." value="<?php if(isset($row['email'])) {echo $row['email'] ;}?>" required>
                
                <input class="edit_admin_textbox form-control" type="password" id="admin_password" name="admin_password" placeholder="Type your admin password here..." value="" required>

                <input class="edit_admin_textbox form-control" type="text" id="admin_occupation" name="admin_occupation" placeholder="Type your admin occupation here..." value="<?php if(isset($row['occupation'])) {echo $row['occupation'] ;}?>" required>
                
                <input class="edit_admin_textbox form-control" type="text" id="admin_social" name="admin_social" placeholder="Type your admin social link here..." value="<?php if(isset($row['social'])) {echo $row['social'] ;}?>" required>

                <img style="height:8rem; border-radius:1rem;" src="<?php if(isset($row['image'])) {echo $row['image'] ;}?>">

                <input type="hidden" name="image" value="<?php if(isset($row['image'])) {echo $row['image'] ;}?>">
                
                <input type="file" class="edit_admin_textbox form-control" id="admin_img" name="admin_img" accept="image/png, image/jpeg">

                
                <input class="edit_admin_submit" id="adminupdate" type="submit" value="Update" name="adminupdate">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>
    </div>


</body>
</html>


