<?php 
    if(!isset($_SESSION)){
            session_start();
        }
    
        if(isset($_SESSION['is_admin_login'])){
            $adminEmail = $_SESSION['admin'];
            }else{
            header('location:../index.php');
            }

    include('admindata/course_db.php');


    //Update Student details 
    
    if(isset($_REQUEST['stuupdate'])){

        // checking for empty fields 

    if(($_REQUEST['student_id'] == "") ||
     ($_REQUEST['student_name'] == "") ||
     ($_REQUEST['student_email'] == "") || 
     ($_REQUEST['student_password'] == "") || 
     ($_REQUEST['student_status'] == "") || 
     ($_REQUEST['student_occupation'] == "")
     ){
         //if filds missing
         $msg = '<div class="fill_error">Fill All Fields</div>';
         echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
     }
     else {
          $student_id = $_REQUEST['student_id'];
          $student_name = $_REQUEST['student_name'];
          $student_email = $_REQUEST['student_email'];
          $student_password = $_REQUEST['student_password'];
          $student_status = $_REQUEST['student_status'];
          $student_occupation = $_REQUEST['student_occupation'];

          $img_folder = $_REQUEST['image'];
        
          if($_FILES['student_img']['error'] == 0){
          $student_image = $_FILES['student_img']['name'];
          $student_image_temp = $_FILES['student_img']['tmp_name'];
          $img_folder = '../img/user_image/'.$student_image;
          move_uploaded_file($student_image_temp, $img_folder);
          }

          $encpass = password_hash($student_password, PASSWORD_BCRYPT);


          $sql = "UPDATE user SET name = '$student_name', email = '$student_email', password= '$encpass', status= '$student_status', occupation='$student_occupation', image= '$img_folder' WHERE id = '$student_id'";

          if($conn->query($sql) == TRUE){

            //submit success
            //  $msg = '<div class="add_success">Student Update Succesfully</div>';
            //  echo '<meta http-equiv="refresh" content="0;URL=?updated" />';
            header("Location: admin_student.php");
         }
         else{
            //  $msg = '<div class="fill_error">Unable to Update Student</div>';
            //  echo '<meta http-equiv="refresh" content="0;URL=?fail_to_update" />';
         }
     }
 }
?>





<!DOCTYPE html>
<html>
<head>
	<title>Edit Student</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="admin_css/edit_student.css">
    <link href="admin_css/admin_dash.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">
</head>
<body>
<div class="edit_body">
    <div class="edit_student_main">
        <div class="edit_student_head">Edit Student</div>

        <?php
            if(isset($_REQUEST['view'])){
                $sql = "SELECT * FROM user WHERE id = {$_REQUEST['s_id']}";

            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
        }
        ?>

        <div class="edit_student_upper">
            <form class="edit_student_login" action="" method="POST" enctype="multipart/form-data">
                
                <input class="edit_student_textbox form-control" type="text" id="student_id" name="student_id" placeholder="Type your student id here..." value="<?php if(isset($row['id'])) {echo $row['id'] ;}?>" readonly>

                <input class="edit_student_textbox form-control" type="text" id="student_name" name="student_name" placeholder="Type your student name here..." value="<?php if(isset($row['name'])) {echo $row['name'] ;}?>" required>
                
                <input class="edit_student_textbox form-control" type="email" id="student_email" name="student_email" placeholder="Type your student email here..." value="<?php if(isset($row['email'])) {echo $row['email'] ;}?>" required>
                
                <input class="edit_student_textbox form-control" type="password" id="student_password" name="student_password" placeholder="Type your student password here..." value="" required>

                <input class="edit_student_textbox form-control" type="text" id="student_occupation" name="student_occupation" placeholder="Type your student occupation here..." value="<?php if(isset($row['occupation'])) {echo $row['occupation'] ;}?>" required>
                
                <img style="height:8rem; border-radius:1rem;" src="<?php if(isset($row['image'])) {echo $row['image'] ;}?>">

                <input type="hidden" name="image" value="<?php if(isset($row['image'])) {echo $row['image'] ;}?>">

                <input type="file" class="edit_student_textbox form-control" id="student_img" name="student_img" accept="image/png, image/jpeg">

                <select class="edit_student_textbox form-control" name="student_status" id="student_status" placeholder="Select Student Status here..." required>
                    <option value="<?php if(isset($row['status'])) {echo $row['status'] ;}?>"><?php if(isset($row['status'])) {echo $row['status'] ;}?></option>
                    <option value="verified">Verified</option>
                    <option value="notverified">not verified</option>
                </select>
                
                <input class="edit_student_submit" id="stuupdate" type="submit" value="Update" name="stuupdate">

                <?php if(isset($msg)) {echo $msg;} ?>
            </form>
        </div>
    </div>
    </div>


</body>
</html>


