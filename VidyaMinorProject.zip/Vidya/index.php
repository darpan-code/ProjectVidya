<!-- database link -->

<?php
  if(!isset($_SESSION)){
    session_start();
  }
    date_default_timezone_set('Asia/Kolkata');
    include('database/connection.php');
  ?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=`, initial-scale=1.0">

  <!-- ---------Favicon---------- -->
  <link rel="icon" type="image/x-icon" href="img/favicon.ico">

  <!-- css file path -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/vidya_home.css">
  <link rel="stylesheet" href="css/why us to learn.css">
  <link rel="stylesheet" href="css/features.css">
  <link rel="stylesheet" href="css/course_home.css">
  <link rel="stylesheet" href="css/feedback.css">
  <link rel="stylesheet" href="css/register.css">
  <link rel="stylesheet" href="css/future_goal.css">
  <link rel="stylesheet" href="css/about_us.css">
  <link rel="stylesheet" href="css/our_team.css">
  <link rel="stylesheet" href="css/let_us_connect.css">
  <link rel="stylesheet" href="css/footer.css">
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  <link rel="stylesheet" href="css/chat-bot.css" />
  <link rel="stylesheet" href="css/login.css" />
  <link rel="stylesheet" href="admin/admin_css/admin_login.css" />
  <link rel="stylesheet" href="css/loader.css" />
  <link rel="stylesheet" href="css/media.css" />



  <!-- reference your copy Font Awesome here (from our CDN or by hosting yourself) -->
  <link href="css/all.min.css" rel="stylesheet">


  <title>Vidya</title>
</head>

<body>

  <div class="loader_bg">
      <img src="img/loaderblue.gif" alt="loader">
  </div>

  <section id="home">

<div class="nav-bar bgcolor" id="div">
    <div>
      <a class="nav-bar-brand" href="index.php">Vidya</a>
    </div>
  <ul class="nav justify-content-center">
    <li class="nav-item">
      <div class="nav-hover">
        <a class="nav-link active" aria-current="page" href="#home">Home</a>
      </div>
    </li>
    <li class="nav-item">
    <div class="nav-hover">
        <a class="nav-link active" aria-current="page" href="#courses">Courses</a>
      </div>
    </li>
    <li class="nav-item">
      <div class="nav-hover">
        <a class="nav-link active" href="#feedback">Feedback</a>
      </div>
    </li>
    <li class="nav-item">
      <div class="nav-hover">
        <a class="nav-link active" href="#contact_us">Contact</a>
      </div>
    </li>
    <li class="nav-item">
      <div class="nav-hover">
        <a class="nav-link log-btn" data-bs-toggle="modal" data-bs-target="#user_login" href="#">Login</a>
      </div>
    </li>
  </ul>
</div>

  <!-- navigation bar end -->
        <div class="home_image">
        <img class="home_img" src="img/home.png" alt="" srcset="">
      </div>

      <!-- background end -->

      <!-- tagline start -->
      <div class="tag-line">
        <p><span class="tag-type"></span></p>
        <div class="center">
          <a href="#" class="get-btn" data-bs-toggle="modal" data-bs-target="#user_signup">Get Started</a>
        </div>
      </div>
      <!-- tagline end -->
    </div>
  </div>
  <!-- video background end -->
</section>
  <!-- why us to learn Start -->

  <div class="learn">
    <p class="learn_head">Why Us to Learn</p>
    <p class="learn_para desc-p-fcolor">With the help these features you can learn the needed lessons as per your need
    <p>
  </div>

  <div class="d-flex justify-content-center bg_why" data-aos="fade-right">
    <div class="why_img">
      <img src="img/why_us_to_learn.png" alt="Why Us to Learn">
    </div>

    <div class="p-2 bg-why-right">
      <div class="why-right-container">
        <!-- why container start -->
        <div class="why-right">
          <p><i class='fas fa-graduation-cap'></i>Get Real Skills</p>
          <div class="why-right-details desc-p-fcolor">
            <p>Our quality curriculum is designed with top-tier industry partners, not academics so you learn the
              skills.</p>
          </div>
        </div>
        <!-- why container stop -->

        <!-- why container start -->
        <div class="why-right">
          <p><i class="fas fa-globe-asia"></i>Native Language Supports</p>
          <div class="why-right-details desc-p-fcolor">
            <p>Language can't be a barrier. So, we give you the opportunity to do the course in your own Languages. Why
              do you miss this opportunity?</p>
          </div>
        </div>
        <!-- why container stop -->

        <!-- why container start -->
        <div class="why-right">
          <p><i class="fas fa-user-clock"></i>Learn On Your Schedule</p>
          <div class="why-right-details desc-p-fcolor">
            <p>Self-paced learning-whenever and wherever you want. Graduate while learning part-time for 12hrs/week.
            </p>
          </div>
        </div>
        <!-- why container stop -->

        <!-- why container start -->
        <div class="why-right" id="why-right-bottom">
          <p><i class="fas fa-code"></i>Project Based Learning</p>
          <div class="why-right-details desc-p-fcolor">
            <p>Learn by doing with real-world projects and other hands-on exercises that lead to real skills.</p>
          </div>
        </div>
        <!-- why container stop -->
      </div>
    </div>
  </div>
  <!-- why us to learn Stop-->

  <!-- features Start -->

  <div class="feature">
    <p class="feature_head">Features</p>
  </div>
  <div>
    <div class="d-flex justify-content-center bg_feature" data-aos="fade-left">

      <div class="p-2 bg-feature-right">
        <div class="feature-right-container">
          <!-- feature container start -->
          <div class="feature-right">
            <p><i class="fas fa-book-reader"></i>Learn From Anywhere</p>
            <div class="feature-right-details desc-p-fcolor">
              <p>You can access our site from any platform like Laptop/Tablet/Mobile.</p>
            </div>
          </div>
          <!-- feature container stop -->

          <!-- feature container start -->
          <div class="feature-right">
            <p><i class="fas fa-award"></i>Get verified certificate</p>
            <div class="feature-right-details desc-p-fcolor">
              <p>We serve you, the curious reader who loves to learn new things every day. Vidyais home to thousands of
                independent voices, and we combine humans and technology to find the best reading for you.</p>
            </div>
          </div>
          <!-- feature container stop -->

          <!-- feature container start -->
          <div class="fea feature-right">
            <p><i class="fas fa-play-circle"></i>Video courses on your language</p>
            <div class="feature-right-details desc-p-fcolor">
              <p>You can access courses various languages.</p>
            </div>
          </div>
          <!-- feature container stop -->

          <!-- feature container start -->
          <div class="feature-right">
            <p><i class="fas fa-chalkboard-teacher"></i>Expert teachers</p>
            <div class="feature-right-details desc-p-fcolor">
              <p>We provide You best possible teacher on your demand.</p>
            </div>
          </div>
          <!-- feature container stop -->

          <!-- feature container start -->
          <div class="feature-right" id="feature-right-bottom">
            <p><i class="fas fa-comments"></i>24x7 Live Chat Support</p>
            <div class="feature-right-details desc-p-fcolor">
              <p>We provide you 24*7 service for any queries</p>
            </div>
          </div>
          <!-- feature container stop -->
        </div>
      </div>

      <div class="feature_img">
        <img src="img/feature.png" alt="feature">
      </div>
    </div>
    <section id="courses">
  </div>
  <!-- Features Stop-->
  <div>
    <!-- Courses Start -->

    <div class="course_home">
      <p class="course_home_head">Trending Courses</p>
    </div>

    <!-- Courses part 2 Start -->

    <div class="course" data-aos="zoom-in-up">
      <div class="course_in">

        <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active"
              aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1"
              aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2"
              aria-label="Slide 3"></button>
          </div>
          <div class="carousel-inner">

            <!-- course section 1 start -->
            <div class="carousel-item active">

              <div class="course_container">
          
              <?php
                $sql = "SELECT * FROM course LIMIT 3";
                $result = $con->query($sql);
                  if($result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                      $course_id = $row['course_id'];
                      echo '
                      <a href="user/course_details.php?course_id='.$course_id.'">
                      <div>
                        <div class="course_out_bg">
                          <div class="course_in_bg">
                            <div class="course_in_img_bg">
                              <img src="'. str_replace('..', '.', $row['course_image']).'" alt="Course image">
                            </div>
                            <div class="course_desc">
                              <span class="course_title">'.$row['course_name'].'</span>
                              <p>'.$row['course_language'].' <span>'.$row['course_duration'].'</span></p>

                              <div class="course_credit_price">
                                <div>by '.$row['course_author'].'</div>
                                <div>Price - <span class="price_drop"> &#8377;'.$row['course_original_price'].'</span> &#8377;'.$row['course_selling_price'].'</div>
                              </div>
                            </div>
                          </div></a>

                          <div class="course_view_enroll">

                            <a  href="user/course_details.php?course_id='.$course_id.'">
                            <div class="btn_view">
                                View Course
                            </div></a>

                         
                          </div>
                        </div>
                      </div>
                      ';
                    }
                  }
                  ?>               
              </div>
            </div>
            <!-- course section 1 stop -->

           <!-- course section 2 start -->
            <div class="carousel-item">

              <div class="course_container">
              <?php
                $sql = "SELECT * FROM course LIMIT 3, 3";
                $result = $con->query($sql);
                  if($result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                      $course_id = $row['course_id'];
                      echo '
                      <a href="user/course_details.php?course_id='.$course_id.'">
                      <div>
                        <div class="course_out_bg">
                          <div class="course_in_bg">
                            <div class="course_in_img_bg">
                              <img src="'. str_replace('..', '.', $row['course_image']).'" alt="Course image">
                            </div>
                            <div class="course_desc">
                              <span class="course_title">'.$row['course_name'].'</span>
                              <p>'.$row['course_language'].' <span>'.$row['course_duration'].'</span></p>

                              <div class="course_credit_price">
                                <div>by '.$row['course_author'].'</div>
                                <div>Price - <span class="price_drop"> &#8377;'.$row['course_original_price'].'</span> &#8377;'.$row['course_selling_price'].'</div>
                              </div>
                            </div>
                          </div></a>

                          <div class="course_view_enroll">

                            <a  href="user/course_details.php?course_id='.$course_id.'">
                            <div class="btn_view">
                                View Course
                            </div></a>
                         
                          </div>
                        </div>
                      </div>
                      ';
                    }
                  }
                  ?>
              </div>
              </div>
      <!-- course section 2 stop -->

         <!-- course section 3 start -->
            <div class="carousel-item">
              <div class="course_container">
             
                <?php
                $sql = "SELECT * FROM course LIMIT 6,3";
                $result = $con->query($sql);
                  if($result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                      $course_id = $row['course_id'];
                      echo '
                      <a href="user/course_details.php?course_id='.$course_id.'">
                      <div>
                        <div class="course_out_bg">
                          <div class="course_in_bg">
                            <div class="course_in_img_bg">
                              <img src="'. str_replace('..', '.', $row['course_image']).'" alt="Course image">
                            </div>
                            <div class="course_desc">
                              <span class="course_title">'.$row['course_name'].'</span>
                              <p>'.$row['course_language'].' <span>'.$row['course_duration'].'</span></p>

                              <div class="course_credit_price">
                                <div>by '.$row['course_author'].'</div>
                                <div>Price - <span class="price_drop"> &#8377;'.$row['course_original_price'].'</span> &#8377;'.$row['course_selling_price'].'</div>
                              </div>
                            </div>
                          </div></a>

                          <div class="course_view_enroll">

                            <a  href="user/course_details.php?course_id='.$course_id.'">
                            <div class="btn_view">
                                View Course
                            </div></a>

                         
                          </div>
                        </div>
                      </div>
                      ';
                    }
                  }
                  ?>

              </div>
            </div>
            <!-- course section 3 stop -->



          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>

        <!-- All courses button Start-->
        <div>
          <button class="btn_all_courses" type="button" onclick="document.location='user/all_course.php'">Explore
            More</button>
        </div>
        <!-- All courses button Stop-->
      </div>
    </div>

    </section>
    <section id="feedback"></section>
  </div>
  <!-- Courses Stop -->



  <!-- Feedback Sction Start -->

  <div class="feedback">
    <p class="feed_head">Feedback</p>
  </div>


  <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
                  <!-- feedback 1 -->
    <div class="carousel-item active">
        <!-- container start -->
        <div class="feed_container">

    <?php
          $sql = "SELECT * FROM user WHERE feedback IS NOT NULL LIMIT 1;";
          $result = $con->query($sql);
            if($result->num_rows > 0){
              while($row = $result->fetch_assoc()){
                $user_id = $row['id'];
                echo '
    
          <div class="sm_container" data-aos="zoom-in">
            <div class="feed_img">
              <img src="'. str_replace('..', '.', $row['image']).'" alt="user feedbake image">
            </div>

            <div class="feed_comments">
              <p class="comments">“'.$row['feedback'].'” </p>
              <p class="feed_name">― '.$row['name'].', '.$row['occupation'].'</p>
            </div>
         
      </div> ';
            }
          }
          ?>
          </div>
        </div>
        
        <!-- feedback 2 -->
        <div class="carousel-item">
        <div class="feed_container">
        <?php
          $sql = "SELECT * FROM user WHERE feedback IS NOT NULL LIMIT 1,1;";
          $result = $con->query($sql);
            if($result->num_rows > 0){
              while($row = $result->fetch_assoc()){
                $user_id = $row['id'];
                echo '
    
          <div class="sm_container" data-aos="zoom-in">
            <div class="feed_img">
              <img src="'. str_replace('..', '.', $row['image']).'" alt="user feedbake image">
            </div>

            <div class="feed_comments">
              <p class="comments">“'.$row['feedback'].'” </p>
              <p class="feed_name">― '.$row['name'].', '.$row['occupation'].'</p>
            </div>
         
      </div> ';
            }
          }
          ?>
        </div>
      </div>
              <!-- feedback 3 -->
      <div class="carousel-item">
        <div class="feed_container">
        <?php
          $sql = "SELECT * FROM user WHERE feedback IS NOT NULL LIMIT 2,1;";
          $result = $con->query($sql);
            if($result->num_rows > 0){
              while($row = $result->fetch_assoc()){
                $user_id = $row['id'];
                echo '
    
          <div class="sm_container" data-aos="zoom-in">
            <div class="feed_img">
              <img src="'. str_replace('..', '.', $row['image']).'" alt="user feedbake image">
            </div>

            <div class="feed_comments">
              <p class="comments">“'.$row['feedback'].'” </p>
              <p class="feed_name">― '.$row['name'].', '.$row['occupation'].'</p>
            </div>
         
      </div> ';
            }
          }
          ?>
        </div>
      </div>

                    <!-- feedback 4 -->
      <div class="carousel-item">
        <div class="feed_container">
        <?php
          $sql = "SELECT * FROM user WHERE feedback IS NOT NULL LIMIT 3,1;";
          $result = $con->query($sql);
            if($result->num_rows > 0){
              while($row = $result->fetch_assoc()){
                $user_id = $row['id'];
                echo '
    
          <div class="sm_container" data-aos="zoom-in">
            <div class="feed_img">
              <img src="'. str_replace('..', '.', $row['image']).'" alt="user feedbake image">
            </div>

            <div class="feed_comments">
              <p class="comments">“'.$row['feedback'].'” </p>
              <p class="feed_name">― '.$row['name'].', '.$row['occupation'].'</p>
            </div>
         
      </div> ';
            }
          }
          ?>
        </div>
      </div>

                    <!-- feedback 5 -->
      <div class="carousel-item">
        <div class="feed_container">
        <?php
          $sql = "SELECT * FROM user WHERE feedback IS NOT NULL LIMIT 4,1;";
          $result = $con->query($sql);
            if($result->num_rows > 0){
              while($row = $result->fetch_assoc()){
                $user_id = $row['id'];
                echo '
    
          <div class="sm_container" data-aos="zoom-in">
            <div class="feed_img">
              <img src="'. str_replace('..', '.', $row['image']).'" alt="user feedbake image">
            </div>

            <div class="feed_comments">
              <p class="comments">“'.$row['feedback'].'” </p>
              <p class="feed_name">― '.$row['name'].', '.$row['occupation'].'</p>
            </div>
         
      </div> ';
            }
          }
          ?>
        </div>
      </div>

    </div>
  </div>
  </section>
  <!-- Feedback Sction Stop -->

  <!-- Register Sction Start -->
  <div class="reg_main_container" data-aos="fade">
    <div class="reg_container">
      <div class="reg_up">
        <div class="reg_head">
          <p>Register To Grow Your Skill</p>
        </div>
        <div class="reg_btn">
          <button data-bs-toggle="modal" data-bs-target="#user_signup">REGISTER TODAY</button>
        </div>
      </div>

      <div class="reg_down">
        <p>E-learn is the fastest-growing field in tech, and the career opportunities are limitless. </p>
      </div>
    </div>
  </div>

  <!-- Register Sction Stop -->



  <!-- Future Goal Sction Start -->

  <div class="future_goal">
    <p>Our Future Goal</p>
  </div>

  <div class="furute_main_container" data-aos="fade-right">
    <div class="future_img">
      <img src="img/future_goal.png" alt="Future Goal Image">
    </div>

    <div class="future_desc">
      <p>Our mission is to train the people in the careers of the future. The learners can prepare themselves in own
        language. At present we provide English, Hindi, Bengali but in future we want to reach many more regional
        languages.</p>
      </div>
    </div>
    <section id="adout_us">
  </div>
  
  </div>

  <!-- Future Goal Sction Stop -->



  <!-- About Us Sction Start -->

  <div class="about_us">
    <p>About Us</p>
  </div>

  <div class="about_us_main_container" data-aos="fade-left">

    <div class="about_us_desc">
      <p class="about_head">Dear learner Welcome to Vidya</p>

      <div class="about_body">
        <p>Vidya is a Professional E-learning Platform for the best of Courses. We started Vidya with special purpose,
          to provide the finest Courses to users in your regional language, which you will like very much.</p>
      </div>

      <p class="about_body_head">
        At Vidya we are dedicated to:-
      <ul class="body_head_points">
        <li>Focusing on finding you the best Online education in your regional language.</li>
        <li>giving you a pleasant experience</li>
        <li>providing quality service</li>
      </ul>
      </p>
      <p class="about_other_details">We're working to turn our passion for E-learning into a booming online website. We
        hope you enjoy our E-learning as much as we enjoy offering them to you.</p>

      <p class="about_help">If you need any help at all please don't hesitate to contact us.</p>

      <p class="about_greetings">Thank you!<br>From all of us at Vidya</p>
    </div>


    <div class="about_us_img">
      <img src="img/about_us.png" alt="About Us Image">
    </div>

  </div>
  </div>
  </div>

  <!-- About Us Sction Stop -->
  </section>
  <!-- Meet Our team Sction Start -->
  <div>
    <div class="our_team">
      <p>Meet Our Team</p>
    </div>

    <div class="team_main_container" data-aos="fade-up">

    <?php
          $sql = "SELECT * FROM admin;";
          $result = $con->query($sql);
            if($result->num_rows > 0){
              while($row = $result->fetch_assoc()){
                $admin_id = $row['id'];
                echo '
      <div class="team_container">
        <div class="team_member_img">
          <img src="'. str_replace('..', '.', $row['image']).'" alt="Team Member Image">
        </div>
        <p class="team_member_name">'.$row['name'].'</p>
        <div class="team_member_occupation">
          <p>'.$row['occupation'].'</p>
        </div>
        <a href="'.$row['social'].'" target="_blank">
          <i class="fab fa-linkedin-in team_member_social"></i>
        </a>
      </div>';
    }
  }
  ?>

    </div>

<?php

    // checking for entry 
    if(isset($_REQUEST['send_sms'])){

       if(
        ($_REQUEST['user_name'] == "") ||
        ($_REQUEST['user_email'] == "") || 
        ($_REQUEST['user_subject'] == "") || 
        ($_REQUEST['user_subject'] == "") || 
        ($_REQUEST['user_sms'] == "")
        ){
            $msg = '<div class="fill_error">Fill All Fields</div>';
            echo '<meta http-equiv="refresh" content="0;URL=?fill_all_fields" />';
        }
        else {
             $user_name = $_REQUEST['user_name'];
             $user_email = $_REQUEST['user_email'];
             $user_subject = $_REQUEST['user_subject'];
             $user_sms = $_REQUEST['user_sms'];
             
             $sql = "INSERT INTO contact (name, email, subject, message) VALUES ('$user_name', '$user_email', '$user_subject', '$user_sms')";


             if($con->query($sql) == TRUE){
                $msg = '<span class="add_success">Message Send Succesfully</span>';
                echo '<meta http-equiv="refresh" content="0;URL=?Message_Send_Succesfully" />';
            }
            else{
                $msg = '<span class="fill_error">Unable to Send Message</span>';
                echo '<meta http-equiv="refresh" content="0;URL=?Unable_to_Send_Message" />';
            }
        }
    }
?>

    <section id="contact_us"></section>
  </div>

  <!-- Meet Our team Sction Stop -->

  <!-- Let Us connect Sction Start -->


  <div class="let_us_Header">
    <h1>Let Us Connect</h1>
    <p>If you've any issues with using Vidya please let us know by filling the Vidya support form.</p>
  </div>


  <div class="let_us_Container" data-aos="flip-right">



    <div class="let_us_Body">
      <div class="let_us_Img"></div>

      <div class="let_us_Info">
      <form  action="" method="POST" >

        <input type="text" id="user_name" name="user_name" class="let_us_Form let_us_UserName" placeholder="Type your Name Here" value="" required>

        <input type="email" id="user_email" name="user_email" class="let_us_Form let_us_Email" placeholder="Type your E-mail Here" value="" required>

        <input type="text" id="user_subject" name="user_subject" class="let_us_Form let_us_Subject" placeholder="Type Subject Here" value="" required>

        <textarea id="user_sms" name="user_sms" class="let_us_Form let_us_Message let_us_cmt" placeholder="Type your Message Here" value="" required></textarea>

        <input class="let_us_Submit" type="submit" value="Send Message" name="send_sms">
      
        <?php if(isset($msg)) {echo $msg;} ?>
      </form>
      </div>
    </div>

  </div>
  </section>
  <!-- Let Us connect Sction Stop -->


  <!-- Footer Sction Start -->
  <div class="footer">
    <div class="footer_main_container">
      <div class="footer_quick_link footer_space">
        <p class="footer_head">Quick Links</p>
        <ul>
          <a href="#home"><li>Home</li></a>
          <a href="#courses"><li>All Courses</li></a>
          <a href="#contact_us"><li>Contact Us</li></a>
          <a href="#adout_us"><li>About Us</li></a>
          <a href="https://www.termsfeed.com/live/53de634e-e214-4e8d-89c7-f10e450b03d3" target="_blank"><li>Privacy Policy</li></a>
          <a href="https://www.privacypolicies.com/live/7716fd5d-48ff-4b46-b62e-27239b6223bb" target="_blank"><li>T&C</li></a>
        </ul>
      </div>

      <div class="footer_find_us footer_space">
        <p class="footer_head"><i class="fas fa-map-marker-alt"></i>Find Us</p>
        <address>
          Dharampur, Shantiniketan, Near Khadina More, Chinsura, Chinsurah-Mogra, West Bengal <br> PIN - 712101
        </address>
      </div>

      <div class="footer_locate footer_space">
        <p class="footer_head">We Are Located In</p>
        <div class="footer_map">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14702.36117166882!2d88.3817298!3d22.8915885!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xe94a8f21ca53259a!2sTechno%20India%20Hooghly!5e0!3m2!1sen!2sin!4v1636910772497!5m2!1sen!2sin"
            width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
      </div>

    </div>

    <div class="footer_cpyr">
      <div class="f_copy">
        &copy; <a href="#" style="text-decoration: none; color: white;"  data-bs-toggle="modal" data-bs-target="#admin_login"> Copyright 2021-22 Vidya Inc. All Rights Reserved</a>
      </div>
      <div class="f_social">

        <a href="http://facebook.com" target="_blank">
          <i class="fab fa-facebook"></i>
        </a>

        <a href="https://www.linkedin.com/in/darpanchakraborty/" target="_blank">
          <i class="fab fa-linkedin-in"></i>
        </a>

        <a href="http://youtube.com" target="_blank">
          <i class="fab fa-youtube"></i>
        </a>

        <a href="https://github.com/darpan-code/vidya" target="_blank">
          <i class="fab fa-github"></i>
        </a>
      </div>

    </div>
  </div>
  <!-- Footer Sction Stop -->



  
  <!-- Chat Bot Section start -->
  <button class="BtnChat" id="BtnChat" onclick="openForm()"><img src="img/chat-bot.png" alt=""></button>
  
  <div id="myForm" class="ChatWindow">
    <!-- <div class="card">
      <div class="card-body messages-box">
        <ul class="list-unstyled messages-list">
          <?php
            $res=mysqli_query($con,"select * from message");
            if(mysqli_num_rows($res)>0){
              $html='';
              while($row=mysqli_fetch_assoc($res)){
                $message=$row['message'];
                $added_on=$row['added_on'];
                $strtotime=strtotime($added_on);
                $time=date('h:i A',$strtotime);
                $type=$row['type'];
                if($type=='user'){
                  $class="messages-me";
                  $imgAvatar="user-bot.png";
                  $name="Me";
                }else{
                  $class="messages-you";
                  $imgAvatar="bot.png";
                  $name="Vidya";
                }
                $html.='<li class="'.$class.' clearfix"><span class="message-img"><img src="img/'.$imgAvatar.'" class="avatar-sm rounded-circle"></span><div class="message-body clearfix"><div class="message-header"><strong class="messages-title">'.$name.'</strong> <small class="time-messages text-muted"><span class="fas fa-time"></span> <span class="minutes">'.$time.'</span></small> </div><p class="messages-p">'.$message.'</p></div></li>';
              }
              echo $html;
            }else{
              ?>
                      <li class="messages-you clearfix">
                        <span class="message-img">
                          <img src="img/chat-bot.png" class="avatar-sm rounded-circle"></span>
                          <div class="message-body clearfix">
                            <div class="message-header">
                              <strong class="messages-title">Vidya<sup>beta</sup></strong>
                              <small class="time-messages text-muted"><span class="fas fa-time"></span> <span class="minutes">     </span></small>
                               </div>
                               <p class="messages-p">Welcome to vidya.<br>How can I help you?</p>
                              </div>
                        </li>
                      <?php
            }
            ?>

        </ul>
      </div>
      <div class="card-header">
        <div class="input-group">
          <input id="input-me" type="text" name="messages" class="form-control input-sm"
            placeholder="Type your message here..." />
          <span class="input-group-append">
            <button id="chat-btn" class="btn-bot" onclick="send_msg()"><i class="fas fa-arrow-circle-right"></i></button>
          </span>
        </div>
      </div>
    </div> -->

    <?php include('chat_bot.php');?>
    <button class="Btnclose"  onclick="closeForm()"><i class="fas fa-times"></i></button>
  </div> 



<!-- 
  <button id="BtnChat" class="BtnChat">
    <div class="Icon Icon-chat">
      <img height="60rem" src="img/chat-bot.png" alt="chat-bot">
    </div>
    <svg class="Icon Icon-cross" width="20" height="20" viewBox="0 0 20 20">
      <desc>cross</desc>
      <path
        d="M11.41 10l4.29-4.29c.19-.18.3-.43.3-.71a1.003 1.003 0 00-1.71-.71L10 8.59l-4.29-4.3a1.003 1.003 0 00-1.42 1.42L8.59 10 4.3 14.29c-.19.18-.3.43-.3.71a1.003 1.003 0 001.71.71l4.29-4.3 4.29 4.29c.18.19.43.3.71.3a1.003 1.003 0 00.71-1.71L11.41 10z"
        fill-rule="evenodd"></path>
    </svg>
  </button> -->


 
  <!-- Chat Bot Section stop -->


    <!-- login page modal start-->
    <!-- Button trigger modal -->

      <!-- user Signup Modal -->
      <div class="modal fade" id="user_signup" tabindex="-1" aria-labelledby="user_signupLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
              <?php include('signup-user.php');?>
            </div>
          </div>
        </div>
      </div>

       <!-- user login Modal -->
      <div class="modal fade" id="user_login" tabindex="-1" aria-labelledby="user_loginLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
            <!-- <div class="login_main">
                <div class="login_head">User Login</div>
                <div class="login_upper">
                    <form class="user_login" action="">
                        
                        <input class="login_textbox" type="email" id="sign_email" name="user_lname" placeholder="Type your email here..." value="">

                        <input class="login_textbox" type="password" id="sign_password" name="user_password" placeholder="Type your password here..." value="">
                        
                        <input class="user_submit" type="submit" value="Log in">

                        <p class="create">Don't have an account? <a href="#">Log in</a> </p>
                    </form>
                </div>
            </div> -->
               <?php include('login-user.php');?>
            </div>
          </div>
        </div>
      </div>
    <!-- login page modal stop-->

      <!-- Modal -->
      <!-- <div class="modal fade" id="admin_login" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-body"> -->

            <div class="modal fade" id="admin_login" tabindex="-1" aria-labelledby="admin_loginLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-body">

              <?php include('admin/adminlogin.php');?>
            </div>
          </div>
        </div>
      </div>







  <!-- Java Script file path -->
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
  <script src="js/type.js"></script>
  <script src="js/scroll.js"></script>
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/chat-box.js"></script>
  <script src="js/chat-bot.js"></script>
  <script src="js/loader.js"></script>

  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


</body>

</html>