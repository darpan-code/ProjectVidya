<?php
include('../database/controllerUserData.php');

    if(!isset($_SESSION)){
            session_start();
        }
    
        if(isset($_SESSION['email'])){
            $useremail = $_SESSION['email'];
            }else{
            header('location:../index.php');
            }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lessons</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="user_css/lesson_video.css" rel="stylesheet"> 
    <link href="../css/media.css" rel="stylesheet">

</head>
<body>


    <!-- navbar -->
    
    <div class="user_nav">
    <a href="user_dash.php"><div class="user_navlink">  Dashboard </div></a>
    <a href="user_course.php"><div class="user_navlink active"> My Course </div></a>
    <a href="all_course.php"><div class="user_navlink"> All Course </div></a>
    <a href="user_paymentStatus.php"><div class="user_navlink"> Payment Status </div></a>
    <a href="user_feedback.php"><div class="user_navlink"> Feedback </div></a>
    <a href="user_profile.php"><div class="user_navlink"> <i class="fas fa-user-circle"></i> </div></a>
    <a href="../logout-user.php"><div class="user_navlink"> <i class="fas fa-sign-out-alt"></i></div></a>
    </div>


    <div class="container-fluid" style="margin-top:6rem;">
        <div class="row">
        <div class="col-sm-3 border-right">
        <h1 class="text-center">Lessons</h1>
        <ul id="playlist" class="nav flex-column">
            <?php
                if(isset($_GET['course_id'])){
                    $course_id = $_GET['course_id'];
                    $sql = "SELECT * FROM lesson WHERE course_id = '$course_id'";
                    $result = $con->query($sql);
                    if($result->num_rows > 0){
                        while($row = $result->fetch_assoc()){
                            echo '<li class= "nav-item border-bottom py-2" movieurl='.$row['lesson_link'].' style="cursor:pointer;">'.$row['lesson_name'].'</li>';
                        }
                    } ?>
    </ul>
        </div>
        <div class="col-sm-8">
            <video id="videoarea" src="" class="mt-5 w-100 ml-2" controls>
            </video>
            <?php     
                $sql = "SELECT quiz_link FROM course WHERE course_id = '$course_id'";
                $result = $con->query($sql);  
                $row = $result->fetch_assoc();     
            echo '<a class="btn btn-secondary" target="_blank" href="'.$row['quiz_link'].'" role="button"><i class="fas fa-pen"></i> Start test</a> <span class="note">*Take Exam and Get Certificate</span>';
                }
            ?>
        </div>
        </div>
        </div>






        
        <script src='../js/jquery.js' type="text/javascript"></script>
        <script src='../js/custom.js' type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>