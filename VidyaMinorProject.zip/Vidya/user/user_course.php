<?php require_once "../database/controllerUserData.php"; ?>
<?php      
    if(isset($_SESSION['email'])){
        $useremail = $_SESSION['email'];
        }else{
        header('location:../index.php');
        }

?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Course</title>
    <link rel="icon" type="image/x-icon" href="../img/favicon.ico">

    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="../css/all.min.css" rel="stylesheet">
    <link href="user_css/user_dash.css" rel="stylesheet">
    <link href="user_css/all_course.css" rel="stylesheet">
    <link href="../css/media.css" rel="stylesheet">

</head>
<body>

    <!-- navbar -->
    
    <div class="user_nav">
    <a href="user_dash.php"><div class="user_navlink">  Dashboard </div></a>
    <a href="user_course.php"><div class="user_navlink active"> My Course </div></a>
    <a href="all_course.php"><div class="user_navlink"> All Course </div></a>
    <a href="user_paymentStatus.php"><div class="user_navlink"> Payment Status </div></a>
    <a href="user_feedback.php"><div class="user_navlink"> Feedback </div></a>
    <a href="user_profile.php"><div class="user_navlink"> <i class="fas fa-user-circle"></i> </div></a>
    <a href="../logout-user.php"><div class="user_navlink"> <i class="fas fa-sign-out-alt"></i></div></a>
    </div>




    <div class="grid_container">



<!-- Courses Start -->


  <!-- Courses part 1 Start -->

  <?php
  if(isset($useremail)){

  }
      $sql = "SELECT co.order_id, c.course_id, c.course_name, c.course_duration, c.course_language, c.course_image, c.course_author, c.course_original_price, c.course_selling_price FROM courseorder AS co JOIN course AS c ON c.course_id = co.course_id WHERE co.user_email = '$useremail' AND co.status = 'TXN_SUCCESS'";

      $result = $con->query($sql);
          if($result->num_rows > 0){
          while($row = $result->fetch_assoc()){
            $course_id = $row['course_id'];
              ?>
            
              
              <div class="grid_item">
             <?php echo '<a href="lessons_video.php?course_id='.$course_id.'"> ';?>
            
              <div class="course_out_bg">
                  <div class="course_in_bg">
                  <div class="course_in_img_bg">
                      <img src="<?php echo $row['course_image'];?>" alt="Course image">
                  </div>
                  <div class="course_desc">
                      <span class="course_title"><?php echo $row['course_name'];?></span>
                      <p><?php echo $row['course_language'];?> <span><?php echo $row['course_duration'];?></span></p>

                      <div class="course_credit_price">
                      <div>by <?php echo $row['course_author'];?></div>
                      <div>Price - <span class="price_drop"> &#8377;<?php echo $row['course_original_price'];?></span> &#8377;<?php echo $row['course_selling_price'];?></div>
                      </div>
                  </div>
                  </div></a>
                <?php
                echo '
                  <div class="course_view_enroll">
                  
                  <a  href="lessons_video.php?course_id='.$course_id.'">
                  <div class="btn_enroll">
                      Watch
                  </div></a>';
                  ?>

                 
              </div>
              </div>
              </div>
           <?php 
          }
          }
          ?>               
          <!-- course section 1 stop -->

</div>

<div style="width: auto; height: 5rem; background: rgba(0, 0, 0, 0);"></div>








    
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>

</html>